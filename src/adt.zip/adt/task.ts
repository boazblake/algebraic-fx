/**
 * Task<A> - Lazy, cancellable asynchronous computation
 * Fantasy-Land compliant Functor, Applicative, Monad
 */

import { fl } from "./fl";

// Core Type
export interface Task<A> {
  readonly _tag: "Task";
  readonly run: (signal?: AbortSignal) => Promise<A>;
  [fl.map]<B>(f: (a: A) => B): Task<B>;
  [fl.ap]<B>(fab: Task<(a: A) => B>): Task<B>;
  [fl.chain]<B>(f: (a: A) => Task<B>): Task<B>;
}

// Constructor
export const Task = <A>(
  computation: (signal?: AbortSignal) => Promise<A>
): Task<A> => {
  const task: Task<A> = {
    _tag: "Task",
    run: computation,
    [fl.map]: <B>(f: (a: A) => B) =>
      Task(async (signal) => {
        const a = await computation(signal);
        if (signal?.aborted) throw new Error("Aborted");
        return f(a);
      }),
    [fl.ap]: <B>(fab: Task<(a: A) => B>) =>
      Task(async (signal) => {
        const [fn, a] = await Promise.all([
          fab.run(signal),
          computation(signal),
        ]);
        if (signal?.aborted) throw new Error("Aborted");
        return fn(a);
      }),
    [fl.chain]: <B>(f: (a: A) => Task<B>) =>
      Task(async (signal) => {
        const a = await computation(signal);
        if (signal?.aborted) throw new Error("Aborted");
        return f(a).run(signal);
      }),
  };
  return task;
};

// Run the task
const run =
  <A>(signal?: AbortSignal) =>
  (task: Task<A>): Promise<A> =>
    task.run(signal);

// Point-free Helpers
const map =
  <A, B>(f: (a: A) => B) =>
  (task: Task<A>): Task<B> =>
    task[fl.map](f);

const ap =
  <A, B>(fab: Task<(a: A) => B>) =>
  (task: Task<A>): Task<B> =>
    task[fl.ap](fab);

const chain =
  <A, B>(f: (a: A) => Task<B>) =>
  (task: Task<A>): Task<B> =>
    task[fl.chain](f);

const of = <A>(value: A): Task<A> => Task(async () => value);

// Utility Functions
const fromPromise = <A>(p: Promise<A>): Task<A> => Task(() => p);

const delay =
  (ms: number) =>
  <A>(value: A): Task<A> =>
    Task(
      (signal) =>
        new Promise((resolve, reject) => {
          const timeout = setTimeout(() => resolve(value), ms);
          signal?.addEventListener("abort", () => {
            clearTimeout(timeout);
            reject(new Error("Aborted"));
          });
        })
    );

const sleep = (ms: number): Task<void> => delay(ms)(undefined);

const tryCatch = <A>(
  f: (signal?: AbortSignal) => Promise<A>,
  onError: (e: unknown) => A
): Task<A> =>
  Task(async (signal) => {
    try {
      return await f(signal);
    } catch (e) {
      return onError(e);
    }
  });

const flatten = <A>(tta: Task<Task<A>>): Task<A> =>
  chain<Task<A>, A>((ta) => ta)(tta);

const race = <A>(tasks: readonly Task<A>[]): Task<A> =>
  Task((signal) => Promise.race(tasks.map((t) => t.run(signal))));

const all = <A>(tasks: readonly Task<A>[]): Task<readonly A[]> =>
  Task((signal) => Promise.all(tasks.map((t) => t.run(signal))));

// Sequence and Traverse
const sequence = <A>(tasks: readonly Task<A>[]): Task<readonly A[]> =>
  all(tasks);

const traverse =
  <A, B>(f: (a: A) => Task<B>) =>
  (as: readonly A[]): Task<readonly B[]> =>
    sequence(as.map(f));

// Namespace Export
export const TaskModule = {
  of,
  map,
  ap,
  chain,
  run,
  fromPromise,
  delay,
  sleep,
  tryCatch,
  flatten,
  race,
  all,
  sequence,
  traverse,
  [fl.of]: of,
};
