/**
 * Writer<W, A> - Computation with accumulated log
 * Fantasy-Land compliant Functor, Applicative, Monad
 */

import { fl } from "./fl";
import type { Monoid } from "./monoid";

// Core Type
export interface Writer<W, A> {
  readonly _tag: "Writer";
  readonly run: () => readonly [A, W];
  [fl.map]<B>(f: (a: A) => B): Writer<W, B>;
  [fl.chain]<B>(f: (a: A) => Writer<W, B>): Writer<W, B>;
}

// Constructor
export const Writer =
  <W>(monoid: Monoid<W>) =>
  <A>(computation: () => readonly [A, W]): Writer<W, A> => {
    const writer: Writer<W, A> = {
      _tag: "Writer",
      run: computation,
      [fl.map]: <B>(f: (a: A) => B): Writer<W, B> =>
        Writer(monoid)(() => {
          const [a, w] = computation();
          return [f(a), w];
        }),
      [fl.chain]: <B>(f: (a: A) => Writer<W, B>): Writer<W, B> =>
        Writer(monoid)(() => {
          const [a, w1] = computation();
          const [b, w2] = f(a).run();
          return [b, monoid.concat(w1, w2)];
        }),
    };
    return writer;
  };

// Factory for Writer operations with a specific monoid
export const makeWriter = <W>(monoid: Monoid<W>) => {
  const writerConstructor = Writer(monoid);

  // Run the Writer
  const run = <A>(writer: Writer<W, A>): readonly [A, W] => writer.run();

  // Point-free Helpers
  const map =
    <A, B>(f: (a: A) => B) =>
    (writer: Writer<W, A>): Writer<W, B> =>
      writer[fl.map](f);

  const chain =
    <A, B>(f: (a: A) => Writer<W, B>) =>
    (writer: Writer<W, A>): Writer<W, B> =>
      writer[fl.chain](f);

  const of = <A>(value: A): Writer<W, A> =>
    writerConstructor(() => [value, monoid.empty]);

  // Writer-specific Operations
  const tell = (w: W): Writer<W, void> =>
    writerConstructor(() => [undefined, w]);

  const listen = <A>(writer: Writer<W, A>): Writer<W, readonly [A, W]> =>
    writerConstructor(() => {
      const [a, w] = writer.run();
      return [[a, w], w];
    });

  const pass = <A>(
    writer: Writer<W, readonly [A, (w: W) => W]>
  ): Writer<W, A> =>
    writerConstructor(() => {
      const [[a, f], w] = writer.run();
      return [a, f(w)];
    });

  const censor =
    <A>(f: (w: W) => W) =>
    (writer: Writer<W, A>): Writer<W, A> =>
      writerConstructor(() => {
        const [a, w] = writer.run();
        return [a, f(w)];
      });

  // Extract just the value
  const evalWriter = <A>(writer: Writer<W, A>): A => {
    const [a] = writer.run();
    return a;
  };

  // Extract just the log
  const execWriter = <A>(writer: Writer<W, A>): W => {
    const [, w] = writer.run();
    return w;
  };

  // Utility Functions
  const flatten = <A>(wwa: Writer<W, Writer<W, A>>): Writer<W, A> =>
    chain<Writer<W, A>, A>((wa) => wa)(wwa);

  // Sequence and Traverse
  const sequence = <A>(
    writers: readonly Writer<W, A>[]
  ): Writer<W, readonly A[]> =>
    writerConstructor(() => {
      const results: A[] = [];
      let accumulatedLog = monoid.empty;

      for (const writer of writers) {
        const [a, w] = writer.run();
        results.push(a);
        accumulatedLog = monoid.concat(accumulatedLog, w);
      }

      return [results, accumulatedLog];
    });

  const traverse =
    <A, B>(f: (a: A) => Writer<W, B>) =>
    (as: readonly A[]): Writer<W, readonly B[]> =>
      sequence(as.map(f));

  return {
    of,
    map,
    chain,
    run,
    tell,
    listen,
    pass,
    censor,
    eval: evalWriter,
    exec: execWriter,
    flatten,
    sequence,
    traverse,
    [fl.of]: of,
  };
};

// Export constructor and factory
export const WriterModule = {
  Writer,
  makeWriter,
};
