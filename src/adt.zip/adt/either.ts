/**
 * Either<L, R> - Disjoint union representing failure (Left) or success (Right)
 * Fantasy-Land compliant Bifunctor, Monad
 */

import { fl } from "./fl";

// Core Types
export type Either<L, R> = Left<L, R> | Right<L, R>;

export interface Left<L, R> {
  readonly _tag: "Left";
  readonly value: L;
  [fl.map]<B>(f: (r: R) => B): Either<L, B>;
  [fl.bimap]<L2, R2>(f: (l: L) => L2, g: (r: R) => R2): Either<L2, R2>;
  [fl.ap]<B>(fab: Either<L, (r: R) => B>): Either<L, B>;
  [fl.chain]<B>(f: (r: R) => Either<L, B>): Either<L, B>;
}

export interface Right<L, R> {
  readonly _tag: "Right";
  readonly value: R;
  [fl.map]<B>(f: (r: R) => B): Either<L, B>;
  [fl.bimap]<L2, R2>(f: (l: L) => L2, g: (r: R) => R2): Either<L2, R2>;
  [fl.ap]<B>(fab: Either<L, (r: R) => B>): Either<L, B>;
  [fl.chain]<B>(f: (r: R) => Either<L, B>): Either<L, B>;
}

// Constructors
export const Left = <L, R = never>(value: L): Either<L, R> => ({
  _tag: "Left",
  value,
  [fl.map]: <B>(_f: (r: R) => B) => Left<L, B>(value),
  [fl.bimap]: <L2, R2>(f: (l: L) => L2, _g: (r: R) => R2) =>
    Left<L2, R2>(f(value)),
  [fl.ap]: <B>(_fab: Either<L, (r: R) => B>) => Left<L, B>(value),
  [fl.chain]: <B>(_f: (r: R) => Either<L, B>) => Left<L, B>(value),
});

export const Right = <R, L = never>(value: R): Either<L, R> => ({
  _tag: "Right",
  value,
  [fl.map]: <B>(f: (r: R) => B) => Right<B, L>(f(value)),
  [fl.bimap]: <L2, R2>(_f: (l: L) => L2, g: (r: R) => R2) =>
    Right<R2, L2>(g(value)),
  [fl.ap]: <B>(fab: Either<L, (r: R) => B>): Either<L, B> => {
    if (fab._tag === "Left") return Left<L, B>(fab.value);
    return Right<B, L>(fab.value(value));
  },
  [fl.chain]: <B>(f: (r: R) => Either<L, B>) => f(value),
});

// Type Guards
export const isLeft = <L, R>(e: Either<L, R>): e is Left<L, R> =>
  e._tag === "Left";

export const isRight = <L, R>(e: Either<L, R>): e is Right<L, R> =>
  e._tag === "Right";

// Pattern Matching
export const fold =
  <L, R, B>(onLeft: (l: L) => B, onRight: (r: R) => B) =>
  (e: Either<L, R>): B =>
    e._tag === "Left" ? onLeft(e.value) : onRight(e.value);

// Point-free Helpers
const map =
  <R, B>(f: (r: R) => B) =>
  <L>(e: Either<L, R>): Either<L, B> =>
    e[fl.map](f);

const bimap =
  <L, L2, R, R2>(f: (l: L) => L2, g: (r: R) => R2) =>
  (e: Either<L, R>): Either<L2, R2> =>
    e[fl.bimap](f, g);

const ap =
  <L, R, B>(fab: Either<L, (r: R) => B>) =>
  (e: Either<L, R>): Either<L, B> =>
    e[fl.ap](fab);

const chain =
  <L, R, B>(f: (r: R) => Either<L, B>) =>
  (e: Either<L, R>): Either<L, B> =>
    e[fl.chain](f);

const of = <R, L = never>(value: R): Either<L, R> => Right(value);

// Utility Functions
const fromNullable =
  <L>(leftValue: L) =>
  <R>(value: R | null | undefined): Either<L, R> =>
    value == null ? Left(leftValue) : Right(value);

const fromPredicate =
  <L, R>(predicate: (r: R) => boolean, leftValue: (r: R) => L) =>
  (value: R): Either<L, R> =>
    predicate(value) ? Right(value) : Left(leftValue(value));

const tryCatch = <L, R>(
  f: () => R,
  onError: (e: unknown) => L
): Either<L, R> => {
  try {
    return Right(f());
  } catch (e) {
    return Left(onError(e));
  }
};

const getOrElse =
  <R>(defaultValue: R) =>
  <L>(e: Either<L, R>): R =>
    e._tag === "Right" ? e.value : defaultValue;

const swap = <L, R>(e: Either<L, R>): Either<R, L> =>
  e._tag === "Left" ? Right(e.value) : Left(e.value);

const mapLeft =
  <L, L2>(f: (l: L) => L2) =>
  <R>(e: Either<L, R>): Either<L2, R> =>
    e._tag === "Left" ? Left(f(e.value)) : Right(e.value);

// Namespace Export
export const Either = {
  Left,
  Right,
  of,
  map,
  bimap,
  ap,
  chain,
  fold,
  isLeft,
  isRight,
  fromNullable,
  fromPredicate,
  tryCatch,
  getOrElse,
  swap,
  mapLeft,
  [fl.of]: of,
};
