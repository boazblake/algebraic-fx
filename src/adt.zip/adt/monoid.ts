/**
 * Monoid Type Class and Common Instances
 * Provides monoid implementations for common types
 */

import { fl } from "./fl";

export interface Monoid<A> {
  readonly empty: A;
  readonly concat: (x: A, y: A) => A;
}

export interface Semigroup<A> {
  readonly concat: (x: A, y: A) => A;
}

// Sum Monoid
export const monoidSum: Monoid<number> = {
  empty: 0,
  concat: (x, y) => x + y,
};

// Product Monoid
export const monoidProduct: Monoid<number> = {
  empty: 1,
  concat: (x, y) => x * y,
};

// String Monoid
export const monoidString: Monoid<string> = {
  empty: "",
  concat: (x, y) => x + y,
};

// Array Monoid
export const monoidArray = <A>(): Monoid<readonly A[]> => ({
  empty: [],
  concat: (x, y) => [...x, ...y],
});

// Boolean And Monoid
export const monoidAnd: Monoid<boolean> = {
  empty: true,
  concat: (x, y) => x && y,
};

// Boolean Or Monoid
export const monoidOr: Monoid<boolean> = {
  empty: false,
  concat: (x, y) => x || y,
};

// Object Monoid (shallow merge)
export const monoidObject = <A extends Record<string, any>>(): Monoid<A> => ({
  empty: {} as A,
  concat: (x, y) => ({ ...x, ...y }),
});

// Endo Monoid (function composition)
export const monoidEndo = <A>(): Monoid<(a: A) => A> => ({
  empty: (a) => a,
  concat: (f, g) => (a) => f(g(a)),
});

// Helper to combine multiple values with a monoid
export const fold =
  <A>(m: Monoid<A>) =>
  (values: readonly A[]): A =>
    values.reduce(m.concat, m.empty);

// Helper to get monoid instance with FL symbols
export const toFlMonoid = <A>(m: Monoid<A>) => {
  return {
    [fl.empty]: () => m.empty,
    [fl.concat]: (other: A) => m.concat(m.empty, other),
  };
};
