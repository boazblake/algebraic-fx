// Fantasy-Land symbols
export { fl } from "./fl";
export type { FL } from "./fl";

// Monoid
export {
  monoidSum,
  monoidProduct,
  monoidString,
  monoidArray,
  monoidAnd,
  monoidOr,
  fold,
} from "./monoid";
export type { Monoid, Semigroup } from "./monoid";

// Identity
export { Identity, Id } from "./id";
export type { Identity as ID } from "./id";

// Maybe
export {
  Maybe,
  Just,
  Nothing,
  isJust,
  isNothing,
  fold as foldMaybe,
} from "./maybe";
export type { Maybe as MaybeT } from "./maybe";

// Either
export {
  Either,
  Left,
  Right,
  isLeft,
  isRight,
  fold as foldEither,
} from "./either";
export type { Either as EitherT } from "./either";

// IO
export { IO, IOModule } from "./io";
export type { IO as IOT } from "./io";

// Reader
export { Reader, ReaderModule } from "./reader";
export type { Reader as ReaderT } from "./reader";

// Task
export { Task, TaskModule } from "./task";
export type { Task as TaskT } from "./task";

// State
export { State, StateModule } from "./state";
export type { State as StateT } from "./state";

// Validation
export {
  ValidationModule,
  Success,
  Failure,
  isSuccess,
  isFailure,
  makeValidation,
  semigroupArray,
  semigroupString,
} from "./validation";
export type { Validation, Validation as ValidationT } from "./validation";

// Writer
export { Writer, WriterModule } from "./writer";
export type { Writer as WriterT } from "./writer";

// WriterTask
export { WriterTask, WriterTaskModule, makeWriterTask } from "./writer-task";
export type { WriterTask as WriterTaskT } from "./writer-task";

// Stream
export { Stream, StreamModule, createStream } from "./stream";
export type { Stream as StreamT } from "./stream";
