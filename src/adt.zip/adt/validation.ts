/**
 * Validation<E, A> - Accumulating validation with Semigroup
 * Fantasy-Land compliant Functor, Applicative (not Monad - ap accumulates)
 */

import { fl } from "./fl";

// Core Types
export type Validation<E, A> = Failure<E, A> | Success<E, A>;

export interface Failure<E, A> {
  readonly _tag: "Failure";
  readonly errors: E;
  readonly [fl.map]: <B>(f: (a: A) => B) => Validation<E, B>;
  readonly [fl.ap]: <B>(fab: Validation<E, (a: A) => B>) => Validation<E, B>;
}

export interface Success<E, A> {
  readonly _tag: "Success";
  readonly value: A;
  readonly [fl.map]: <B>(f: (a: A) => B) => Validation<E, B>;
  readonly [fl.ap]: <B>(fab: Validation<E, (a: A) => B>) => Validation<E, B>;
}

// Semigroup for combining errors
export interface Semigroup<A> {
  readonly concat: (x: A, y: A) => A;
}

// Constructors
export const Failure = <E, A = never>(errors: E): Validation<E, A> => ({
  _tag: "Failure",
  errors,
  [fl.map]: () => Failure(errors),
  [fl.ap]: (fab) => {
    if (fab._tag === "Failure") {
      // Need semigroup to combine - return first for now
      return Failure(errors);
    }
    return Failure(errors);
  },
});

export const Success = <A, E = never>(value: A): Validation<E, A> => ({
  _tag: "Success",
  value,
  [fl.map]: (f) => Success(f(value)),
  [fl.ap]: (fab) => {
    if (fab._tag === "Failure") return Failure(fab.errors);
    return Success(fab.value(value));
  },
});

// Create Validation with semigroup context
export const makeValidation = <E>(semigroup: Semigroup<E>) => {
  const failure = <A = never>(errors: E): Validation<E, A> => ({
    _tag: "Failure",
    errors,
    [fl.map]: () => failure(errors),
    [fl.ap]: (fab) => {
      if (fab._tag === "Failure") {
        return failure(semigroup.concat(fab.errors, errors));
      }
      return failure(errors);
    },
  });

  const success = <A>(value: A): Validation<E, A> => ({
    _tag: "Success",
    value,
    [fl.map]: (f) => success(f(value)),
    [fl.ap]: (fab) => {
      if (fab._tag === "Failure") return failure(fab.errors);
      return success(fab.value(value));
    },
  });

  return { failure, success };
};

// Type Guards
export const isFailure = <E, A>(v: Validation<E, A>): v is Failure<E, A> =>
  v._tag === "Failure";

export const isSuccess = <E, A>(v: Validation<E, A>): v is Success<E, A> =>
  v._tag === "Success";

// Pattern Matching
export const fold =
  <E, A, B>(onFailure: (e: E) => B, onSuccess: (a: A) => B) =>
  (v: Validation<E, A>): B =>
    v._tag === "Failure" ? onFailure(v.errors) : onSuccess(v.value);

// Point-free Helpers
const map =
  <A, B>(f: (a: A) => B) =>
  <E>(v: Validation<E, A>): Validation<E, B> =>
    v[fl.map](f);

const ap =
  <E, A, B>(fab: Validation<E, (a: A) => B>) =>
  (v: Validation<E, A>): Validation<E, B> =>
    v[fl.ap](fab);

const of = <A, E = never>(value: A): Validation<E, A> => Success(value);

// Utility Functions
const fromPredicate =
  <E, A>(predicate: (a: A) => boolean, onFailure: (a: A) => E) =>
  (value: A): Validation<E, A> =>
    predicate(value) ? Success(value) : Failure(onFailure(value));

const fromNullable =
  <E>(error: E) =>
  <A>(value: A | null | undefined): Validation<E, A> =>
    value == null ? Failure(error) : Success(value);

const toEither = <E, A>(
  v: Validation<E, A>
): { _tag: "Left" | "Right"; value: E | A } =>
  v._tag === "Failure"
    ? { _tag: "Left", value: v.errors }
    : { _tag: "Right", value: v.value };

const getOrElse =
  <A>(defaultValue: A) =>
  <E>(v: Validation<E, A>): A =>
    v._tag === "Success" ? v.value : defaultValue;

// Combine validations with semigroup
const combine =
  <E>(semigroup: Semigroup<E>) =>
  <A>(v1: Validation<E, A>, v2: Validation<E, A>): Validation<E, A> => {
    if (v1._tag === "Failure" && v2._tag === "Failure") {
      return Failure(semigroup.concat(v1.errors, v2.errors));
    }
    if (v1._tag === "Failure") return v1;
    if (v2._tag === "Failure") return v2;
    return v2; // Both success, return last
  };

// Sequence with semigroup
const sequence =
  <E>(semigroup: Semigroup<E>) =>
  <A>(vs: readonly Validation<E, A>[]): Validation<E, readonly A[]> => {
    const results: A[] = [];
    let errors: E | null = null;

    for (const v of vs) {
      if (v._tag === "Failure") {
        errors =
          errors === null ? v.errors : semigroup.concat(errors, v.errors);
      } else {
        results.push(v.value);
      }
    }

    return errors === null ? Success(results) : Failure(errors);
  };

// Traverse with semigroup
const traverse =
  <E>(semigroup: Semigroup<E>) =>
  <A, B>(f: (a: A) => Validation<E, B>) =>
  (as: readonly A[]): Validation<E, readonly B[]> =>
    sequence(semigroup)(as.map(f));

// Common semigroups
export const semigroupArray = <A>(): Semigroup<readonly A[]> => ({
  concat: (x, y) => [...x, ...y],
});

export const semigroupString: Semigroup<string> = {
  concat: (x, y) => x + y,
};

// Namespace Export
export const ValidationModule = {
  Success,
  Failure,
  makeValidation,
  of,
  map,
  ap,
  fold,
  isFailure,
  isSuccess,
  fromPredicate,
  fromNullable,
  toEither,
  getOrElse,
  combine,
  sequence,
  traverse,
  semigroupArray,
  semigroupString,
  [fl.of]: of,
};
