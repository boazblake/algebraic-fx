/**
 * Reader<R, A> - Environment-dependent computation
 * Fantasy-Land compliant Functor, Applicative, Monad
 */

import { fl } from "./fl";
import type { IO } from "./io";
import { IO as IOConstructor } from "./io";

// Core Type
export interface Reader<R, A> {
  readonly _tag: "Reader";
  readonly run: (r: R) => A;
  [fl.map]<B>(f: (a: A) => B): Reader<R, B>;
  [fl.ap]<B>(fab: Reader<R, (a: A) => B>): Reader<R, B>;
  [fl.chain]<B>(f: (a: A) => Reader<R, B>): Reader<R, B>;
}

// Constructor
export const Reader = <R, A>(run: (r: R) => A): Reader<R, A> => ({
  _tag: "Reader",
  run,
  [fl.map]: <B>(f: (a: A) => B) => Reader((r: R) => f(run(r))),
  [fl.ap]: <B>(fab: Reader<R, (a: A) => B>) =>
    Reader((r: R) => fab.run(r)(run(r))),
  [fl.chain]: <B>(f: (a: A) => Reader<R, B>) =>
    Reader((r: R) => f(run(r)).run(r)),
});

// Run the reader with an environment
const runReader =
  <R, A>(env: R) =>
  (reader: Reader<R, A>): A =>
    reader.run(env);

// Point-free Helpers
const map =
  <A, B>(f: (a: A) => B) =>
  <R>(reader: Reader<R, A>): Reader<R, B> =>
    reader[fl.map](f);

const ap =
  <R, A, B>(fab: Reader<R, (a: A) => B>) =>
  (reader: Reader<R, A>): Reader<R, B> =>
    reader[fl.ap](fab);

const chain =
  <R, A, B>(f: (a: A) => Reader<R, B>) =>
  (reader: Reader<R, A>): Reader<R, B> =>
    reader[fl.chain](f);

const of = <R, A>(value: A): Reader<R, A> => Reader(() => value);

// Reader-specific Operations
const ask = <R>(): Reader<R, R> => Reader((r: R) => r);

const asks = <R, A>(f: (r: R) => A): Reader<R, A> => Reader(f);

const local =
  <R, R2>(f: (r2: R2) => R) =>
  <A>(reader: Reader<R, A>): Reader<R2, A> =>
    Reader((r2: R2) => reader.run(f(r2)));

// Convert IO to Reader (ignoring environment)
const fromIO = <R, A>(io: IO<A>): Reader<R, A> => Reader(() => io.run());

// Run Reader and return result as IO
const runIO =
  <R, A>(env: R) =>
  (reader: Reader<R, A>): IO<A> =>
    IOConstructor(() => reader.run(env));

// Utility Functions
const flatten = <R, A>(rra: Reader<R, Reader<R, A>>): Reader<R, A> =>
  chain<R, Reader<R, A>, A>((ra) => ra)(rra);

// Sequence and Traverse
const sequence = <R, A>(
  readers: readonly Reader<R, A>[]
): Reader<R, readonly A[]> =>
  Reader((r: R) => readers.map((reader) => reader.run(r)));

const traverse =
  <R, A, B>(f: (a: A) => Reader<R, B>) =>
  (as: readonly A[]): Reader<R, readonly B[]> =>
    sequence(as.map(f));

// Namespace Export
export const ReaderModule = {
  of,
  map,
  ap,
  chain,
  ask,
  asks,
  local,
  run: runReader,
  fromIO,
  runIO,
  flatten,
  sequence,
  traverse,
  [fl.of]: of,
};
