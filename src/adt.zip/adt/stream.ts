/**
 * Stream<A> - Minimal FRP implementation for reactive programming
 * Supports subscription, mapping, filtering, scanning, debouncing, and event sources
 */

import { fl } from "./fl";

// Core Types
export type Listener<A> = (value: A) => void;
export type Unsubscribe = () => void;

export interface Stream<A> {
  readonly _tag: "Stream";
  readonly subscribe: (listener: Listener<A>) => Unsubscribe;
  [fl.map]<B>(f: (a: A) => B): Stream<B>;
}

// Constructor
export const Stream = <A>(
  subscribe: (listener: Listener<A>) => Unsubscribe
): Stream<A> => {
  const stream: Stream<A> = {
    _tag: "Stream",
    subscribe,
    [fl.map]: <B>(f: (a: A) => B): Stream<B> =>
      Stream<B>((listener: Listener<B>) => subscribe((a: A) => listener(f(a)))),
  };
  return stream;
};

// Create a stream with manual emission
export const createStream = <A>(): readonly [Stream<A>, (value: A) => void] => {
  const listeners = new Set<Listener<A>>();

  const stream = Stream<A>((listener) => {
    listeners.add(listener);
    return () => {
      listeners.delete(listener);
    };
  });

  const emit = (value: A) => {
    listeners.forEach((listener) => listener(value));
  };

  return [stream, emit];
};

// Point-free map
const map =
  <A, B>(f: (a: A) => B) =>
  (stream: Stream<A>): Stream<B> =>
    stream[fl.map](f);

// Filter values
const filter =
  <A>(predicate: (a: A) => boolean) =>
  (stream: Stream<A>): Stream<A> =>
    Stream((listener) =>
      stream.subscribe((a) => {
        if (predicate(a)) listener(a);
      })
    );

// Scan (reduce over time)
const scan =
  <A, B>(f: (acc: B, a: A) => B, initial: B) =>
  (stream: Stream<A>): Stream<B> => {
    let acc = initial;
    return Stream((listener) => {
      listener(acc); // Emit initial value
      return stream.subscribe((a) => {
        acc = f(acc, a);
        listener(acc);
      });
    });
  };

// Debounce
const debounce =
  (ms: number) =>
  <A>(stream: Stream<A>): Stream<A> =>
    Stream((listener) => {
      let timeoutId: ReturnType<typeof setTimeout> | null = null;

      const unsub = stream.subscribe((a) => {
        if (timeoutId !== null) clearTimeout(timeoutId);
        timeoutId = setTimeout(() => {
          listener(a);
          timeoutId = null;
        }, ms);
      });

      return () => {
        if (timeoutId !== null) clearTimeout(timeoutId);
        unsub();
      };
    });

// Throttle
const throttle =
  (ms: number) =>
  <A>(stream: Stream<A>): Stream<A> =>
    Stream((listener) => {
      let lastEmit = 0;
      let timeoutId: ReturnType<typeof setTimeout> | null = null;
      let lastValue: A | undefined;
      let hasLastValue = false;

      const unsub = stream.subscribe((a) => {
        const now = Date.now();
        const timeSinceLastEmit = now - lastEmit;

        if (timeSinceLastEmit >= ms) {
          listener(a);
          lastEmit = now;
          hasLastValue = false;
        } else {
          lastValue = a;
          hasLastValue = true;

          if (timeoutId === null) {
            timeoutId = setTimeout(() => {
              if (hasLastValue) {
                listener(lastValue!);
                lastEmit = Date.now();
                hasLastValue = false;
              }
              timeoutId = null;
            }, ms - timeSinceLastEmit);
          }
        }
      });

      return () => {
        if (timeoutId !== null) clearTimeout(timeoutId);
        unsub();
      };
    });

// Merge multiple streams
const merge = <A>(streams: readonly Stream<A>[]): Stream<A> =>
  Stream((listener) => {
    const unsubscribes = streams.map((stream) => stream.subscribe(listener));
    return () => {
      unsubscribes.forEach((unsub) => unsub());
    };
  });

// Combine latest values from multiple streams
const combine = <A extends readonly any[]>(
  ...streams: { [K in keyof A]: Stream<A[K]> }
): Stream<A> =>
  Stream((listener) => {
    const values = new Array(streams.length);
    const hasValue = new Array(streams.length).fill(false);

    const checkAndEmit = () => {
      if (hasValue.every(Boolean)) {
        // Create a new array and cast it
        const result = values.slice();
        listener(result as unknown as A);
      }
    };

    const unsubscribes = streams.map((stream, index) =>
      stream.subscribe((value) => {
        values[index] = value;
        hasValue[index] = true;
        checkAndEmit();
      })
    );

    return () => {
      unsubscribes.forEach((unsub) => unsub());
    };
  });

// Sample one stream with another
const sample =
  <A, B>(sampler: Stream<B>) =>
  (stream: Stream<A>): Stream<A> =>
    Stream((listener) => {
      let lastValue: A | undefined;
      let hasValue = false;

      const unsubStream = stream.subscribe((a) => {
        lastValue = a;
        hasValue = true;
      });

      const unsubSampler = sampler.subscribe(() => {
        if (hasValue) {
          listener(lastValue!);
        }
      });

      return () => {
        unsubStream();
        unsubSampler();
      };
    });

// Take first n values
const take =
  (n: number) =>
  <A>(stream: Stream<A>): Stream<A> =>
    Stream((listener) => {
      let count = 0;
      let unsub: Unsubscribe | null = null;

      unsub = stream.subscribe((a) => {
        if (count < n) {
          listener(a);
          count++;
          if (count >= n && unsub) {
            unsub();
          }
        }
      });

      return () => {
        if (unsub) unsub();
      };
    });

// Skip first n values
const skip =
  (n: number) =>
  <A>(stream: Stream<A>): Stream<A> =>
    Stream((listener) => {
      let count = 0;
      return stream.subscribe((a) => {
        if (count >= n) {
          listener(a);
        }
        count++;
      });
    });

// Stream from DOM event
const fromEvent = <K extends keyof HTMLElementEventMap>(
  target: HTMLElement | Window | Document,
  eventName: K
): Stream<HTMLElementEventMap[K]> =>
  Stream((listener) => {
    const handler = (event: Event) => listener(event as HTMLElementEventMap[K]);
    target.addEventListener(eventName, handler);
    return () => target.removeEventListener(eventName, handler);
  });

// Stream from interval
const interval = (ms: number): Stream<number> =>
  Stream((listener) => {
    let count = 0;
    const id = setInterval(() => {
      listener(count++);
    }, ms);
    return () => clearInterval(id);
  });

// Stream from promise
const fromPromise = <A>(promise: Promise<A>): Stream<A> =>
  Stream((listener) => {
    promise.then(listener).catch(() => {});
    return () => {};
  });

// Stream from array (emits each element)
const fromArray = <A>(arr: readonly A[]): Stream<A> =>
  Stream((listener) => {
    arr.forEach(listener);
    return () => {};
  });

// Distinct until changed
const distinctUntilChanged =
  <A>(eq: (a: A, b: A) => boolean = (a, b) => a === b) =>
  (stream: Stream<A>): Stream<A> =>
    Stream((listener) => {
      let lastValue: A | undefined;
      let hasLast = false;

      return stream.subscribe((a) => {
        if (!hasLast || !eq(lastValue!, a)) {
          listener(a);
          lastValue = a;
          hasLast = true;
        }
      });
    });

// Start with an initial value
const startWith =
  <A>(initial: A) =>
  (stream: Stream<A>): Stream<A> =>
    Stream((listener) => {
      listener(initial);
      return stream.subscribe(listener);
    });

// Namespace Export
export const StreamModule = {
  Stream,
  createStream,
  map,
  filter,
  scan,
  debounce,
  throttle,
  merge,
  combine,
  sample,
  take,
  skip,
  fromEvent,
  interval,
  fromPromise,
  fromArray,
  distinctUntilChanged,
  startWith,
  [fl.map]: map,
};
