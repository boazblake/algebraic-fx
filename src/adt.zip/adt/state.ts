/**
 * State<S, A> - Stateful computation
 * Fantasy-Land compliant Functor, Applicative, Monad
 */

import { fl } from "./fl";

// Core Type
export interface State<S, A> {
  readonly _tag: "State";
  readonly run: (s: S) => readonly [A, S];
  readonly [fl.map]: <B>(f: (a: A) => B) => State<S, B>;
  readonly [fl.ap]: <B>(fab: State<S, (a: A) => B>) => State<S, B>;
  readonly [fl.chain]: <B>(f: (a: A) => State<S, B>) => State<S, B>;
}

// Constructor
export const State = <S, A>(run: (s: S) => readonly [A, S]): State<S, A> => ({
  _tag: "State",
  run,
  [fl.map]: (f) =>
    State((s: S) => {
      const [a, s2] = run(s);
      return [f(a), s2];
    }),
  [fl.ap]: (fab) =>
    State((s: S) => {
      const [fn, s2] = fab.run(s);
      const [a, s3] = run(s2);
      return [fn(a), s3];
    }),
  [fl.chain]: (f) =>
    State((s: S) => {
      const [a, s2] = run(s);
      return f(a).run(s2);
    }),
});

// Run the state computation
const runState =
  <S, A>(initialState: S) =>
  (state: State<S, A>): readonly [A, S] =>
    state.run(initialState);

const evalState =
  <S, A>(initialState: S) =>
  (state: State<S, A>): A =>
    state.run(initialState)[0];

const execState =
  <S, A>(initialState: S) =>
  (state: State<S, A>): S =>
    state.run(initialState)[1];

// Point-free Helpers
const map =
  <A, B>(f: (a: A) => B) =>
  <S>(state: State<S, A>): State<S, B> =>
    state[fl.map](f);

const ap =
  <S, A, B>(fab: State<S, (a: A) => B>) =>
  (state: State<S, A>): State<S, B> =>
    state[fl.ap](fab);

const chain =
  <S, A, B>(f: (a: A) => State<S, B>) =>
  (state: State<S, A>): State<S, B> =>
    state[fl.chain](f);

const of = <S, A>(value: A): State<S, A> => State((s: S) => [value, s]);

// State-specific Operations
const get = <S>(): State<S, S> => State((s: S) => [s, s]);

const put = <S>(s: S): State<S, void> => State(() => [undefined, s]);

const modify = <S>(f: (s: S) => S): State<S, void> =>
  State((s: S) => [undefined, f(s)]);

const gets = <S, A>(f: (s: S) => A): State<S, A> => State((s: S) => [f(s), s]);

// Utility Functions
const flatten = <S, A>(ssa: State<S, State<S, A>>): State<S, A> =>
  chain<S, State<S, A>, A>((sa) => sa)(ssa);

// Sequence and Traverse
const sequence = <S, A>(
  states: readonly State<S, A>[]
): State<S, readonly A[]> =>
  State((s: S) => {
    const results: A[] = [];
    let currentState = s;

    for (const state of states) {
      const [a, nextState] = state.run(currentState);
      results.push(a);
      currentState = nextState;
    }

    return [results, currentState];
  });

const traverse =
  <S, A, B>(f: (a: A) => State<S, B>) =>
  (as: readonly A[]): State<S, readonly B[]> =>
    sequence(as.map(f));

// Namespace Export
export const StateModule = {
  of,
  map,
  ap,
  chain,
  get,
  put,
  modify,
  gets,
  run: runState,
  eval: evalState,
  exec: execState,
  flatten,
  sequence,
  traverse,
  [fl.of]: of,
};
