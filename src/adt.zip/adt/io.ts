/**
 * IO<A> - Lazy synchronous effect
 * Fantasy-Land compliant Functor, Applicative, Monad
 */

import { fl } from "./fl";

// Core Type
export interface IO<A> {
  readonly _tag: "IO";
  readonly run: () => A;
  [fl.map]<B>(f: (a: A) => B): IO<B>;
  [fl.ap]<B>(fab: IO<(a: A) => B>): IO<B>;
  [fl.chain]<B>(f: (a: A) => IO<B>): IO<B>;
}

// Constructor
export const IO = <A>(thunk: () => A): IO<A> => {
  const io: IO<A> = {
    _tag: "IO",
    run: thunk,
    [fl.map]: <B>(f: (a: A) => B) => IO(() => f(thunk())),
    [fl.ap]: <B>(fab: IO<(a: A) => B>) => IO(() => fab.run()(thunk())),
    [fl.chain]: <B>(f: (a: A) => IO<B>) => IO(() => f(thunk()).run()),
  };
  return io;
};

// Run the effect
const run = <A>(io: IO<A>): A => io.run();

// Point-free Helpers
const map =
  <A, B>(f: (a: A) => B) =>
  (io: IO<A>): IO<B> =>
    io[fl.map](f);

const ap =
  <A, B>(fab: IO<(a: A) => B>) =>
  (io: IO<A>): IO<B> =>
    io[fl.ap](fab);

const chain =
  <A, B>(f: (a: A) => IO<B>) =>
  (io: IO<A>): IO<B> =>
    io[fl.chain](f);

const of = <A>(value: A): IO<A> => IO(() => value);

// Utility Functions
const flatten = <A>(iio: IO<IO<A>>): IO<A> => chain<IO<A>, A>((io) => io)(iio);

const delay =
  (ms: number) =>
  <A>(value: A): IO<A> =>
    IO(() => {
      const start = Date.now();
      while (Date.now() - start < ms) {}
      return value;
    });

const fromSync = <A>(f: () => A): IO<A> => IO(f);

// Sequence and Traverse
const sequence = <A>(ios: readonly IO<A>[]): IO<readonly A[]> =>
  IO(() => ios.map((io) => io.run()));

const traverse =
  <A, B>(f: (a: A) => IO<B>) =>
  (as: readonly A[]): IO<readonly B[]> =>
    sequence(as.map(f));

// Namespace Export
export const IOModule = {
  of,
  map,
  ap,
  chain,
  run,
  flatten,
  delay,
  fromSync,
  sequence,
  traverse,
  [fl.of]: of,
};
