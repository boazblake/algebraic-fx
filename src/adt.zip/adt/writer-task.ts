/**
 * WriterTask<W, A> - Writer monad transformer over Task
 * Accumulates logs of type W using a Monoid while performing async computation
 * Fantasy-Land compliant Functor, Applicative, Monad
 */

import { fl } from "./fl";
import type { Monoid } from "./monoid";
import type { Task } from "./task";
import { Task as TaskConstructor } from "./task";

// Core Type
export interface WriterTask<W, A> {
  readonly _tag: "WriterTask";
  readonly run: (signal?: AbortSignal) => Promise<readonly [A, W]>;
  readonly [fl.map]: <B>(f: (a: A) => B) => WriterTask<W, B>;
  readonly [fl.ap]: <B>(fab: WriterTask<W, (a: A) => B>) => WriterTask<W, B>;
  readonly [fl.chain]: <B>(f: (a: A) => WriterTask<W, B>) => WriterTask<W, B>;
}

// Constructor
export const WriterTask =
  <W>(monoid: Monoid<W>) =>
  <A>(
    computation: (signal?: AbortSignal) => Promise<readonly [A, W]>
  ): WriterTask<W, A> => {
    const wt: WriterTask<W, A> = {
      _tag: "WriterTask",
      run: computation,
      [fl.map]: (f) =>
        WriterTask(monoid)(async (signal) => {
          const [a, w] = await computation(signal);
          if (signal?.aborted) throw new Error("Aborted");
          return [f(a), w];
        }),
      [fl.ap]: (fab) =>
        WriterTask(monoid)(async (signal) => {
          const [[fn, w1], [a, w2]] = await Promise.all([
            fab.run(signal),
            computation(signal),
          ]);
          if (signal?.aborted) throw new Error("Aborted");
          return [fn(a), monoid.concat(w1, w2)];
        }),
      [fl.chain]: (f) =>
        WriterTask(monoid)(async (signal) => {
          const [a, w1] = await computation(signal);
          if (signal?.aborted) throw new Error("Aborted");
          const [b, w2] = await f(a).run(signal);
          return [b, monoid.concat(w1, w2)];
        }),
    };
    return wt;
  };

// Factory for WriterTask operations with a specific monoid
export const makeWriterTask = <W>(monoid: Monoid<W>) => {
  const writerTaskConstructor = WriterTask(monoid);

  // Run the WriterTask
  const run =
    <A>(signal?: AbortSignal) =>
    (wt: WriterTask<W, A>): Promise<readonly [A, W]> =>
      wt.run(signal);

  // Point-free Helpers
  const map =
    <A, B>(f: (a: A) => B) =>
    (wt: WriterTask<W, A>): WriterTask<W, B> =>
      wt[fl.map](f);

  const ap =
    <A, B>(fab: WriterTask<W, (a: A) => B>) =>
    (wt: WriterTask<W, A>): WriterTask<W, B> =>
      wt[fl.ap](fab);

  const chain =
    <A, B>(f: (a: A) => WriterTask<W, B>) =>
    (wt: WriterTask<W, A>): WriterTask<W, B> =>
      wt[fl.chain](f);

  const of = <A>(value: A): WriterTask<W, A> =>
    writerTaskConstructor(async () => [value, monoid.empty]);

  // WriterTask-specific Operations
  const tell = (w: W): WriterTask<W, void> =>
    writerTaskConstructor(async () => [undefined, w]);

  const listen = <A>(wt: WriterTask<W, A>): WriterTask<W, readonly [A, W]> =>
    writerTaskConstructor(async (signal) => {
      const [a, w] = await wt.run(signal);
      return [[a, w], w];
    });

  const pass = <A>(
    wt: WriterTask<W, readonly [A, (w: W) => W]>
  ): WriterTask<W, A> =>
    writerTaskConstructor(async (signal) => {
      const [[a, f], w] = await wt.run(signal);
      return [a, f(w)];
    });

  const censor =
    <A>(f: (w: W) => W) =>
    (wt: WriterTask<W, A>): WriterTask<W, A> =>
      writerTaskConstructor(async (signal) => {
        const [a, w] = await wt.run(signal);
        return [a, f(w)];
      });

  // Convert Task to WriterTask
  const fromTask = <A>(task: Task<A>): WriterTask<W, A> =>
    writerTaskConstructor(async (signal) => {
      const a = await task.run(signal);
      return [a, monoid.empty];
    });

  // Extract just the value
  const evalWriterTask =
    <A>(signal?: AbortSignal) =>
    async (wt: WriterTask<W, A>): Promise<A> => {
      const [a] = await wt.run(signal);
      return a;
    };

  // Extract just the log
  const execWriterTask =
    <A>(signal?: AbortSignal) =>
    async (wt: WriterTask<W, A>): Promise<W> => {
      const [, w] = await wt.run(signal);
      return w;
    };

  // Utility Functions
  const flatten = <A>(wwt: WriterTask<W, WriterTask<W, A>>): WriterTask<W, A> =>
    chain<WriterTask<W, A>, A>((wt) => wt)(wwt);

  // Sequence and Traverse
  const sequence = <A>(
    wts: readonly WriterTask<W, A>[]
  ): WriterTask<W, readonly A[]> =>
    writerTaskConstructor(async (signal) => {
      const results: A[] = [];
      let accumulatedLog = monoid.empty;

      for (const wt of wts) {
        const [a, w] = await wt.run(signal);
        if (signal?.aborted) throw new Error("Aborted");
        results.push(a);
        accumulatedLog = monoid.concat(accumulatedLog, w);
      }

      return [results, accumulatedLog];
    });

  const traverse =
    <A, B>(f: (a: A) => WriterTask<W, B>) =>
    (as: readonly A[]): WriterTask<W, readonly B[]> =>
      sequence(as.map(f));

  return {
    of,
    map,
    ap,
    chain,
    run,
    tell,
    listen,
    pass,
    censor,
    fromTask,
    eval: evalWriterTask,
    exec: execWriterTask,
    flatten,
    sequence,
    traverse,
    [fl.of]: of,
  };
};

// Export constructor and factory
export const WriterTaskModule = {
  WriterTask,
  makeWriterTask,
};
