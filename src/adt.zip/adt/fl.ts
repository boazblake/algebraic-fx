/**
 * Fantasy-Land Symbol Definitions
 * Provides the canonical FL symbol table for algebraic type implementations
 */

export const fl = {
  map: "fantasy-land/map",
  bimap: "fantasy-land/bimap",
  ap: "fantasy-land/ap",
  of: "fantasy-land/of",
  chain: "fantasy-land/chain",
  concat: "fantasy-land/concat",
  empty: "fantasy-land/empty",
  reduce: "fantasy-land/reduce",
  traverse: "fantasy-land/traverse",
  sequence: "fantasy-land/sequence",
  contramap: "fantasy-land/contramap",
  extend: "fantasy-land/extend",
  extract: "fantasy-land/extract",
  alt: "fantasy-land/alt",
  zero: "fantasy-land/zero",
  filter: "fantasy-land/filter",
  filterMap: "fantasy-land/filterMap",
  promap: "fantasy-land/promap",
} as const;

/**
 * Fantasy-Land type-level helpers
 */
export type FL = typeof fl;

export interface Functor<A> {
  readonly [fl.map]: <B>(f: (a: A) => B) => Functor<B>;
}

export interface Apply<A> extends Functor<A> {
  readonly [fl.ap]: <B>(fab: Apply<(a: A) => B>) => Apply<B>;
}

export interface Applicative<A> extends Apply<A> {
  readonly [fl.of]: <B>(b: B) => Applicative<B>;
}

export interface Chain<A> extends Apply<A> {
  readonly [fl.chain]: <B>(f: (a: A) => Chain<B>) => Chain<B>;
}

export interface Monad<A> extends Applicative<A>, Chain<A> {}

export interface Bifunctor<L, R> {
  readonly [fl.bimap]: <L2, R2>(
    f: (l: L) => L2,
    g: (r: R) => R2
  ) => Bifunctor<L2, R2>;
}

export interface Alt<A> extends Functor<A> {
  readonly [fl.alt]: (other: Alt<A>) => Alt<A>;
}

export interface Semigroup<A> {
  readonly [fl.concat]: (other: Semigroup<A>) => Semigroup<A>;
}

export interface Monoid<A> extends Semigroup<A> {
  readonly [fl.empty]: () => Monoid<A>;
}
