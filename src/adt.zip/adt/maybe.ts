/**
 * Maybe<A> - Optional value representing presence (Just) or absence (Nothing)
 * Fantasy-Land compliant Functor, Applicative, Monad, Alt
 */

import { fl } from "./fl";

// Core Types
export type Maybe<A> = Just<A> | Nothing<A>;

export interface Just<A> {
  readonly _tag: "Just";
  readonly value: A;
  [fl.map]<B>(f: (a: A) => B): Maybe<B>;
  [fl.ap]<B>(fab: Maybe<(a: A) => B>): Maybe<B>;
  [fl.chain]<B>(f: (a: A) => Maybe<B>): Maybe<B>;
  [fl.alt](other: Maybe<A>): Maybe<A>;
}

export interface Nothing<A> {
  readonly _tag: "Nothing";
  [fl.map]<B>(f: (a: A) => B): Maybe<B>;
  [fl.ap]<B>(fab: Maybe<(a: A) => B>): Maybe<B>;
  [fl.chain]<B>(f: (a: A) => Maybe<B>): Maybe<B>;
  [fl.alt](other: Maybe<A>): Maybe<A>;
}

// Constructors
export const Just = <A>(value: A): Maybe<A> => ({
  _tag: "Just",
  value,
  [fl.map]: <B>(f: (a: A) => B) => Just(f(value)),
  [fl.ap]: <B>(fab: Maybe<(a: A) => B>) => {
    if (fab._tag === "Nothing") return Nothing<B>();
    return Just(fab.value(value));
  },
  [fl.chain]: <B>(f: (a: A) => Maybe<B>) => f(value),
  [fl.alt]: (_other: Maybe<A>) => Just(value),
});

export const Nothing = <A = never>(): Maybe<A> => {
  const nothing: Maybe<A> = {
    _tag: "Nothing",
    [fl.map]: <B>(_f: (a: A) => B): Maybe<B> => Nothing<B>(),
    [fl.ap]: <B>(_fab: Maybe<(a: A) => B>): Maybe<B> => Nothing<B>(),
    [fl.chain]: <B>(_f: (a: A) => Maybe<B>): Maybe<B> => Nothing<B>(),
    [fl.alt]: (other: Maybe<A>) => other,
  };
  return nothing;
};

// Type Guards
export const isJust = <A>(m: Maybe<A>): m is Just<A> => m._tag === "Just";
export const isNothing = <A>(m: Maybe<A>): m is Nothing<A> =>
  m._tag === "Nothing";

// Pattern Matching
export const fold =
  <A, B>(onNothing: () => B, onJust: (a: A) => B) =>
  (m: Maybe<A>): B =>
    m._tag === "Nothing" ? onNothing() : onJust(m.value);

// Point-free Helpers
const map =
  <A, B>(f: (a: A) => B) =>
  (m: Maybe<A>): Maybe<B> =>
    m[fl.map](f);

const ap =
  <A, B>(fab: Maybe<(a: A) => B>) =>
  (m: Maybe<A>): Maybe<B> =>
    m[fl.ap](fab);

const chain =
  <A, B>(f: (a: A) => Maybe<B>) =>
  (m: Maybe<A>): Maybe<B> =>
    m[fl.chain](f);

const alt =
  <A>(other: Maybe<A>) =>
  (m: Maybe<A>): Maybe<A> =>
    m[fl.alt](other);

const of = <A>(value: A): Maybe<A> => Just(value);

// Utility Functions
const fromNullable = <A>(value: A | null | undefined): Maybe<NonNullable<A>> =>
  value == null ? Nothing() : Just(value as NonNullable<A>);

const fromPredicate =
  <A>(predicate: (a: A) => boolean) =>
  (value: A): Maybe<A> =>
    predicate(value) ? Just(value) : Nothing();

const fromFalsy = <A>(
  value: A | null | undefined | false | 0 | ""
): Maybe<NonNullable<A>> => (value ? Just(value as NonNullable<A>) : Nothing());

const tryCatch = <A>(f: () => A): Maybe<A> => {
  try {
    return Just(f());
  } catch {
    return Nothing();
  }
};

const getOrElse =
  <A>(defaultValue: A) =>
  (m: Maybe<A>): A =>
    m._tag === "Just" ? m.value : defaultValue;

const withDefault =
  <A>(defaultValue: A) =>
  (m: Maybe<A>): A =>
    getOrElse(defaultValue)(m);

const toNullable = <A>(m: Maybe<A>): A | null =>
  m._tag === "Just" ? m.value : null;

const toUndefined = <A>(m: Maybe<A>): A | undefined =>
  m._tag === "Just" ? m.value : undefined;

const filter =
  <A>(predicate: (a: A) => boolean) =>
  (m: Maybe<A>): Maybe<A> =>
    m._tag === "Just" && predicate(m.value) ? m : Nothing();

const exists =
  <A>(predicate: (a: A) => boolean) =>
  (m: Maybe<A>): boolean =>
    m._tag === "Just" && predicate(m.value);

const contains =
  <A>(value: A) =>
  (m: Maybe<A>): boolean =>
    m._tag === "Just" && m.value === value;

// Sequence and Traverse
const sequence = <A>(ms: readonly Maybe<A>[]): Maybe<readonly A[]> => {
  const result: A[] = [];
  for (const m of ms) {
    if (m._tag === "Nothing") return Nothing();
    result.push(m.value);
  }
  return Just(result as readonly A[]);
};

const traverse =
  <A, B>(f: (a: A) => Maybe<B>) =>
  (as: readonly A[]): Maybe<readonly B[]> =>
    sequence(as.map(f));

// Namespace Export
export const Maybe = {
  Just,
  Nothing,
  of,
  map,
  ap,
  chain,
  alt,
  fold,
  isJust,
  isNothing,
  fromNullable,
  fromPredicate,
  fromFalsy,
  tryCatch,
  getOrElse,
  withDefault,
  toNullable,
  toUndefined,
  filter,
  exists,
  contains,
  sequence,
  traverse,
  [fl.of]: of,
};
