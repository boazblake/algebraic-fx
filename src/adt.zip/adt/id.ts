/**
 * Identity<A> - Simplest monad wrapping a value
 * Fantasy-Land compliant Functor, Applicative, Monad
 */

import { fl } from "./fl";

// Core Type
export interface Identity<A> {
  readonly value: A;
  [fl.map]<B>(f: (a: A) => B): Identity<B>;
  [fl.ap]<B>(fab: Identity<(a: A) => B>): Identity<B>;
  [fl.chain]<B>(f: (a: A) => Identity<B>): Identity<B>;
}

// Constructor
export const Identity = <A>(value: A): Identity<A> => ({
  value,
  [fl.map]: <B>(f: (a: A) => B) => Identity(f(value)),
  [fl.ap]: <B>(fab: Identity<(a: A) => B>) => Identity(fab.value(value)),
  [fl.chain]: <B>(f: (a: A) => Identity<B>) => f(value),
});

// Extract value
const extract = <A>(id: Identity<A>): A => id.value;

// Point-free Helpers
const map =
  <A, B>(f: (a: A) => B) =>
  (id: Identity<A>): Identity<B> =>
    id[fl.map](f);

const ap =
  <A, B>(fab: Identity<(a: A) => B>) =>
  (id: Identity<A>): Identity<B> =>
    id[fl.ap](fab);

const chain =
  <A, B>(f: (a: A) => Identity<B>) =>
  (id: Identity<A>): Identity<B> =>
    id[fl.chain](f);

const of = <A>(value: A): Identity<A> => Identity(value);

// Namespace Export
export const Id = {
  of,
  map,
  ap,
  chain,
  extract,
  [fl.of]: of,
};
